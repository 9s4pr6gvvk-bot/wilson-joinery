# SEO and coming-soon deployment

Upload the CONTENTS of wilson-joinery to the Pages project root. The index.html homepage is the established coming-soon design. The complete, optimised homepage remains available at /index2 (index2.html), marked noindex in HTML and worker response headers. Noindex is not password protection. Service pages remain public and indexable, keeping useful destinations for old service links. Sitemap excludes the preview, error page and legacy aliases. Coming-soon root is indexable, with a self-canonical and normal 200 response; replacing the full homepage temporarily may still affect rankings/snippets.

Local Jost fonts, larger WJ favicon, mobile header number, policy and worker are retained. Inputs/selects/textarea use 16px text to avoid iPhone focus zoom while keeping pinch zoom enabled. Forms default to the Wilson business inbox; Cloudflare TO_EMAIL overrides the default.

## SEO work
Unique titles/descriptions; consistent HTTPS www canonicals and extensionless navigation; Open Graph/Twitter previews; WebSite/business/WebPage/Service/breadcrumb structured data; actual project social image; extracted/deduplicated compressed image assets; lazy-loaded content images with intrinsic dimensions; sitemap.xml and robots.txt; legacy 301 redirects; real discontinued-page 404s; noindex preview/Pages deployments. Unconfirmed price/payment/address claims were removed from structured data rather than invented. Confirm business legal/address details before adding complete local business address markup. SEO is not a guarantee of rankings or rich results.

## At full launch
Run python3 launch_full_site.py from the extracted ZIP directory. It replaces coming-soon index.html with the full homepage, restores root home/anchor links, removes preview noindex from index.html, updates canonicals/social/schema homepage URLs to /, and redirects /index2 to /. It keeps a backup of the coming-soon file outside the deployment folder. Then upload the site folder again. Inspect the resulting home page and worker before deploying.

## Live checks
Confirm / returns the coming-soon page, /index2 the normal homepage, service pages return 200, unknown URLs return 404, .html/legacy aliases redirect correctly and query strings persist. Verify robots.txt and sitemap.xml return files rather than the homepage. Check rich-result/schema validity, mobile form behaviour, actual emails and image/layout performance. Submit https://www.wilsonjoinery.co.uk/sitemap.xml to Google Search Console after deployment. Additional old URLs may be identified through Search Console. Confirm the legal/privacy requirements in GDPR-AUDIT.md before launch.

## Local validation
Parsed metadata/JSON-LD, checked all referenced image/font assets, eight sitemap URLs, noindex preview and form font sizes; mocked worker/form tests passed. Full-launch conversion was tested on an isolated copy. A visual browser check could not run because the environment has no installed browser executable. Test actual iPhone focus/zoom, responsive layouts, image rendering and live crawling after deployment.
