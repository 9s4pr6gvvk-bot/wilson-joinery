# Legacy page redirects

Based on URLs found in public search results on 9 October 2026. This is not a complete Search Console index export. Deploying this ZIP activates these 301 redirects in the Pages worker; no extra dashboard rules are needed for these paths. Existing domain redirect rules stay in place.

| Old URL path | New URL path |
| --- | --- |
| `/bespoke-kitchens.html` | `/kitchens` |
| `/bespoke-bedrooms.html` | `/bedrooms` |
| `/bespoke-studies.html` | `/studies` |
| `/storage-solutions.html` | `/storage` |
| `/contact-us.html` | `/index2#contact` |


These redirects were checked locally with mocked assets; live behaviour needs checking after deployment. Test each old URL, including query strings. Search Console may reveal additional URLs to add.

Replacement doors is no longer offered. Its old URL is not redirected and falls through to the normal 404 response.
