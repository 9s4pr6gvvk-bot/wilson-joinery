# Wilson Joinery forms — setup

The `wilson-joinery` folder is the Cloudflare Pages deployment root. It contains the normal homepage, all service pages, a draft privacy page, `_worker.js`, and the form scripts. This is a Pages advanced-mode worker, like JS Tech's, rather than a separate Worker service.

## 1. Resend
Create or use your Resend account. Add and verify the sending domain `mail.wilsonjoinery.co.uk`. Add only the DNS records Resend specifies for that subdomain in Cloudflare. Leave the existing Zoho MX and SPF records for the root domain unchanged. Do not publish a second SPF record at the same hostname. Verify the domain, then create a sending API key restricted to that domain where available.

Default sender: `Wilson Joinery Website <website@mail.wilsonjoinery.co.uk>`.
Recipient: `info@wilsonjoinery.co.uk`.
Reply-To: the visitor's email address, so Reply goes to the enquirer.

## 2. Cloudflare Pages settings
In the `wilson-joinery` Pages project, open Settings → Variables and Secrets and add:

| Name | Type | Value |
| --- | --- | --- |
| `RESEND_API_KEY` | Secret | Your Resend sending API key |
| `TURNSTILE_SECRET_KEY` | Secret | The secret for your Wilson Turnstile widget |
| `TURNSTILE_SITE_KEY` | Text, optional | `0x4AAAAAAFShqK_3A8pdKCfO` — already the code default |
| `FROM_EMAIL` | Text, optional | A sender on your verified Resend domain; defaults as above |
| `TO_EMAIL` | Text, optional | Defaults to `info@wilsonjoinery.co.uk` |

Set production values. Set preview values only if you want forms to send real emails from previews. Keep private keys in secrets, never in HTML, this ZIP, or chat. Redeploy after setting or changing variables.

## 3. Deploy
Deploy the CONTENTS of `wilson-joinery` so `_worker.js` and `index.html` sit at the deployment root. Use your existing deployment method that supports `_worker.js`. If using Wrangler from an authenticated machine:

```sh
npx wrangler pages deploy ./wilson-joinery --project-name wilson-joinery
```

Confirm the deployment includes the worker, not just the static files. Custom domain: `www.wilsonjoinery.co.uk`. Existing `.com` and `.uk` redirect rules can remain. The worker redirects the `.co.uk` root to HTTPS www, preserving paths and query strings; it does not redirect www back to root.

Turnstile allowed hostname: `www.wilsonjoinery.co.uk`. Add `wilson-joinery.pages.dev` only to test there; authorising that hostname also permits its preview subdomains. Tokens must match the actual submission hostname and the `contact` action.

## 4. Test after deployment
Send an enquiry on the homepage and a service page. Check it arrives at info@wilsonjoinery.co.uk with the name, service, phone, project message and originating page. Reply and confirm the recipient is the enquirer. Confirm a missing or invalid Turnstile token is rejected. Confirm failed sends allow retry and never show success. Test mobile layout and any interactive security challenge. Confirm redirects do not loop.

The worker refuses to deliver enquiries when either required secret is missing. Turnstile loads when a visitor starts using a form. Tokens are renewed after failed sends. There is a hidden spam field, server-side input validation, a 32 KiB request limit, and escaped email content. Enquiries go to Resend; no separate enquiry database is created. Provider logs may still exist. Origin checks are an additional control, not a replacement for Turnstile. No persistent rate-limit store is included.

## 5. Privacy policy
The public policy has no draft notes or placeholder fields. Confirm the controller identity, correspondence address, provider settings and retention periods before launch. Jost is now self-hosted, with its SIL Open Font License included.

Local checks use mocked providers; no live email was sent and no deployment, DNS changes or secret setup was performed.

Set Cloudflare TO_EMAIL to info@wilsonjoinery.co.uk or remove the override to use the worker default. Redeploy after changing it.

## Token submission fix (v2)
Form submission now waits for the Turnstile callback and explicitly includes its token in the request. Versioned script URLs avoid stale browser scripts. Upload this entire updated site and refresh before testing.

## Privacy audit update
The policy describes the business inbox and self-hosted fonts. The intro-animation storage flag has been removed. Confirm the legal controller identity, provider arrangements and retention practices listed in GDPR-AUDIT.md.
