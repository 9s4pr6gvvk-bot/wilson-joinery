document.querySelectorAll('.fs-form').forEach(function (form) {
  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    var btn = form.querySelector('.f-submit'), msg = form.querySelector('.f-ok');
    if (btn.disabled) return;
    var original = btn.textContent;
    btn.disabled = true; btn.textContent = 'Checking...'; msg.style.display = 'none';
    try {
      if (!window.wilsonGetTurnstileToken) throw new Error('Security check could not load. Please refresh this page.');
      var token = await window.wilsonGetTurnstileToken(form);
      if (!token) throw new Error('Security check did not finish.');
      var payload = new FormData(form);
      payload.set('cf-turnstile-response', token);
      btn.textContent = 'Sending...';
      var res = await fetch('/api/enquiry', { method: 'POST', signal: AbortSignal.timeout(30000), body: payload, headers: {Accept: 'application/json'} });
      var result = await res.json();
      if (!res.ok || !result.ok) throw new Error(result.error || 'Could not send your enquiry.');
      form.querySelectorAll('input, textarea, select').forEach(function (el) { el.disabled = true; });
      btn.style.display = 'none';
      msg.textContent = "Thank you. We'll be in touch shortly.";
      msg.style.background = '#eef4ef'; msg.style.borderColor = '#c6d9c8'; msg.style.color = '#355a3a';
      msg.style.display = 'block';
    } catch (err) {
      btn.disabled = false; btn.textContent = original;
      msg.textContent = (err.message || 'Could not send your enquiry.') + ' You can also call 07974 848145 or email info@wilsonjoinery.co.uk.';
      msg.style.background = '#fbf1f1'; msg.style.borderColor = '#e4c6c6'; msg.style.color = '#843a3a'; msg.style.display = 'block';
      if (window.wilsonTurnstileReset) window.wilsonTurnstileReset(form);
    }
  });
});
