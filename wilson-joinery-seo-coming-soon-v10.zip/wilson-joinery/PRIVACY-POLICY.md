# Privacy Policy

Last updated: 9 October 2026

Wilson Joinery ("we", "us", "our") respects your privacy. This policy explains what personal data we collect through our website, why we collect it, the legal basis we rely on, who we share it with, how long we keep it and your rights under applicable UK data protection law, including the UK General Data Protection Regulation (UK GDPR), the Data Protection Act 2018 and the Privacy and Electronic Communications Regulations (PECR).

We use your enquiry details to respond to you, discuss your project and arrange any work you ask us to undertake. We do not sell your personal data or use it for marketing you have not requested.

## Who we are

Wilson Joinery is responsible for the personal data described in this policy and acts as its data controller.


For questions about this policy or your personal data, email [info@wilsonjoinery.co.uk](mailto:info@wilsonjoinery.co.uk) or call **07974 848145**.

This policy covers our website at [www.wilsonjoinery.co.uk](https://www.wilsonjoinery.co.uk) and enquiries made to us through the contact methods described below.

## What data we collect

**When you send an enquiry.** Our forms ask for your first and last name, email address and information about your project. You can also provide your phone number and select the service you are interested in. We receive the details you submit, the page from which you sent the enquiry and the date and time. Your first name, last name and email address are required so we can identify and respond to your enquiry. The phone number, service selection and project message are optional. If you do not provide the required details, the form cannot be submitted; you can contact us by phone or email instead.

**When you contact us directly.** If you phone or email us, we keep the information you provide and our correspondence so we can respond and manage your enquiry.

**When a project goes ahead.** We may need further information, such as your site address, access arrangements, project specifications and information needed to prepare quotations, manage the work and issue invoices.

**When you visit the website.** Our hosting and security providers process technical information, such as your IP address, browser and device information, and the pages requested, to deliver the website and protect it from abuse.

**When you use a form.** Cloudflare Turnstile processes technical signals from your browser and device to help distinguish genuine visitors from automated bots.

We do not collect payment card details through this website. Our enquiry forms are not intended to collect sensitive personal information, so please avoid including it in your message.

## How we use your data and our legal basis

| Purpose | Data used | Legal basis |
| --- | --- | --- |
| Responding to an enquiry, preparing a quote or arranging a visit at your request | Contact and project details | Taking steps at your request before entering into a contract; for general or business enquiries, our legitimate interest in responding to people who contact us |
| Carrying out agreed work and providing aftercare | Contact, site and project details, and correspondence | Performance of a contract; where the customer is an organisation, our legitimate interest in managing the business relationship |
| Keeping appropriate business records and dealing with queries or disputes | Enquiry, project and correspondence records | Legitimate interests in managing our business and establishing, exercising or defending legal claims |
| Meeting accounting, tax and other legal requirements | Relevant transaction and business records | Compliance with legal obligations |
| Delivering the website, loading its fonts and maintaining security | Technical data | Legitimate interests in operating a functioning, secure website |
| Preventing spam and automated abuse of our forms | Turnstile security signals | Legitimate interests in protecting our website and inbox |

Where we rely on legitimate interests, we consider the purpose of the processing, whether it is necessary and the effect on your rights and expectations. You can object to this processing using the contact details above.

We will not sell your personal data, share it for another organisation's own marketing or add you to a marketing mailing list without an appropriate basis and any permission required by law.

## Who we share your data with

We use service providers to deliver the website and receive and respond to enquiries. Where a provider acts as our processor, it processes personal data under the relevant contractual arrangements and our instructions.

**Cloudflare.** Cloudflare provides website hosting through Cloudflare Pages, network security and the code that processes enquiry submissions. It handles technical data needed to deliver and secure the website, and submission data when a form is processed. See [Cloudflare's privacy policy](https://www.cloudflare.com/privacypolicy/).

**Cloudflare Turnstile.** Turnstile is the security check used on our forms. It loads when you start using a form. Your browser sends security signals to Cloudflare, and our server sends the resulting token and your IP address for verification before delivering an enquiry. It processes signals such as your IP address and browser information to detect automated activity. Cloudflare states that these signals are used to detect and block bots rather than to identify, profile or target individuals. See [the Turnstile privacy addendum](https://www.cloudflare.com/turnstile-privacy-policy/).

**Website support.** Franks Media provides website maintenance and technical support and may access relevant information where needed to troubleshoot the website or enquiry delivery on our behalf.

**Resend.** Resend delivers enquiry submissions to us by email. It processes the information submitted in the form and associated email delivery information. See [Resend's privacy policy](https://resend.com/legal/privacy-policy).

**Zoho Mail.** Zoho provides our business email service and stores the enquiry emails we receive and our replies. See [Zoho's privacy policy](https://www.zoho.com/privacy.html).

Our Jost fonts are hosted on our own website. Loading them does not connect your browser to Google Fonts or another external font provider.

We may also share relevant information with professional advisers, such as our accountant or legal advisers, or with authorities where disclosure is required by law. If a project requires information to be shared with a tradesperson or supplier, we limit this to what they need to carry out their role.

## Cookies and similar technologies

We do not use analytics, advertising or marketing tracking cookies on this website.

Cloudflare's security services may use strictly necessary cookies or similar technologies to protect the website and prevent automated abuse. Turnstile processes security signals to help protect our enquiry forms. We use these services for security rather than advertising or visitor profiling.

You can manage cookies through your browser settings. Blocking security-related technologies may affect the website or prevent a form from submitting. You can contact us by phone or email instead.

If we introduce non-essential cookies or similar technologies, we will update this policy and obtain consent where required before using them.

## Automated security checks

Turnstile carries out an automated security check. If a submission fails this check, the form may not send. This does not determine whether we will provide a quotation or accept your project.

If you have trouble sending a form, call **07974 848145** or email [info@wilsonjoinery.co.uk](mailto:info@wilsonjoinery.co.uk). We do not use website enquiry data to make decisions producing legal or similarly significant effects solely by automated means.

## International transfers

Our service providers may process or allow access to personal data outside the UK. The countries involved depend on the provider and the service configuration. This includes possible processing in the United States by providers such as Resend.

Where a restricted international transfer takes place, we use an applicable UK adequacy arrangement or appropriate contractual safeguards, such as the UK International Data Transfer Agreement or the UK Addendum to the EU Standard Contractual Clauses, together with any additional measures required.

You can contact us for more information about the safeguards relevant to your personal data and how to obtain a copy, subject to necessary redactions.

## How long we keep your data

We keep personal data only for as long as needed for the purpose for which it was collected.

| Data | Retention period |
| --- | --- |
| Enquiries that do not lead to work | Up to two years after our last substantive contact, then deleted unless there is a specific continuing need |
| Project correspondence and records for completed work | Normally up to six years after completion, where needed for aftercare, business records or potential claims |
| Accounting and tax records | For the period required by the applicable accounting and tax rules |
| Email delivery records | For the period specified by our email delivery provider and the settings applicable to our account |
| Hosting and security information | For the period applicable to the service and its security configuration |

We may retain relevant records for longer where needed to comply with a legal obligation or deal with an ongoing complaint, dispute or claim. Copies in backups may remain until the normal backup deletion cycle completes.

## Your rights

Depending on the circumstances, you have the right to:

- request access to the personal data we hold about you;
- ask us to correct inaccurate or incomplete information;
- ask us to delete your personal data;
- ask us to restrict how we use your personal data;
- object to processing based on legitimate interests;
- receive certain personal data in a portable format; and
- withdraw consent where we rely on it, without affecting processing carried out before withdrawal.

These rights are subject to conditions and exemptions. For example, we may need to retain some records to meet legal obligations.

To make a request, email [info@wilsonjoinery.co.uk](mailto:info@wilsonjoinery.co.uk). Requests are normally free of charge. We may need information to confirm your identity or clarify your request. We normally respond within one month, subject to any extension or adjustment permitted by law, and will explain if one applies.

## Complaints

To make a data protection complaint, email [info@wilsonjoinery.co.uk](mailto:info@wilsonjoinery.co.uk) or call **07974 848145** and explain your concern. We will acknowledge your complaint within 30 days, investigate without undue delay, keep you informed and tell you the outcome.

You also have the right to complain to the Information Commissioner's Office (ICO), the UK's data protection regulator, at [ico.org.uk/make-a-complaint](https://ico.org.uk/make-a-complaint/) or by calling **0303 123 1113**. You do not have to contact us first.

## Keeping your data secure

We use appropriate technical and organisational measures to protect personal data. The website and enquiry submission connections use HTTPS. Access to enquiries is limited to people who need the information to respond to you or manage your project.

Enquiries are delivered to our business email inbox rather than stored in a separate website enquiry database. Our business email service is provided by Zoho Mail. Our hosting, security and email providers may retain processing or delivery records under their own service arrangements.

## Links to other websites

If you follow a link to another website, its operator is responsible for its own processing of your personal data. Please read its privacy information where relevant.

## Changes to this policy

We may update this policy if our services or the way we use personal data changes. The date at the top shows when it was last updated.
