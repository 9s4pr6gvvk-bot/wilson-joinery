/* Wilson Joinery: load Turnstile when a visitor starts using a form.
   The public site key is safe to include here; private verification stays in the worker. */
(function () {
  var SITE_KEY = "0x4AAAAAAFShqK_3A8pdKCfO";
  var states = new WeakMap(), loading;
  function load() {
    if (window.turnstile) return Promise.resolve();
    if (loading) return loading;
    loading = new Promise(function (resolve, reject) {
      var timer = setTimeout(function () { loading = null; reject(new Error('Security check could not load.')); }, 20000);
      window.__wilsonTsReady = function () { clearTimeout(timer); resolve(); };
      var script = document.createElement('script');
      script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=__wilsonTsReady';
      script.async = true;
      script.onerror = function () { clearTimeout(timer); loading = null; reject(new Error('Security check could not load.')); };
      document.head.appendChild(script);
    });
    return loading;
  }
  function state(form) {
    if (!states.has(form)) states.set(form, { token: '', id: null, ready: null, waiters: [] });
    return states.get(form);
  }
  function settle(s, error) {
    s.waiters.splice(0).forEach(function (w) { clearTimeout(w.timer); error ? w.reject(error) : w.resolve(s.token); });
  }
  async function render(form) {
    var s = state(form);
    if (s.ready) return s.ready;
    s.ready = (async function () {
      await load();
      var box = form.querySelector('.ts-box');
      if (!box) throw new Error('Security check is unavailable.');
      s.id = window.turnstile.render(box, {
        sitekey: SITE_KEY, action: 'contact', appearance: 'interaction-only', theme: 'light', size: 'flexible',
        'response-field': false,
        callback: function (token) { s.token = token; settle(s); },
        'expired-callback': function () { s.token = ''; window.turnstile.reset(s.id); },
        'error-callback': function () { s.token = ''; settle(s, new Error('Security check failed. Please retry.')); },
        'timeout-callback': function () { s.token = ''; settle(s, new Error('Security check timed out. Please retry.')); }
      });
    })().catch(function (err) { s.ready = null; throw err; });
    return s.ready;
  }
  window.wilsonGetTurnstileToken = async function (form) {
    await render(form);
    var s = state(form);
    if (s.token) return s.token;
    return new Promise(function (resolve, reject) {
      var w = { resolve: resolve, reject: reject };
      w.timer = setTimeout(function () { s.waiters = s.waiters.filter(function (x) { return x !== w; }); reject(new Error('Security check timed out. Please retry.')); }, 60000);
      s.waiters.push(w);
    });
  };
  window.wilsonTurnstileReset = function (form) {
    var s = state(form); s.token = '';
    if (s.id !== null && window.turnstile) window.turnstile.reset(s.id);
  };
  document.querySelectorAll('.fs-form').forEach(function (form) {
    form.addEventListener('focusin', function () { render(form).catch(function () {}); });
  });
})();
