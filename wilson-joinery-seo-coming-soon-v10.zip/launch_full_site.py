"""Restore the full homepage after the coming-soon period. Run from this ZIP's directory."""
from pathlib import Path
import re,json
root=Path(__file__).resolve().parent;site=root/'wilson-joinery';base='https://www.wilsonjoinery.co.uk'
full=(site/'index2.html').read_text();assert 'noindex' in full
(root/'coming-soon-backup.html').write_text((site/'index.html').read_text())
full=full.replace(base+'/index2',base+'/')
full=re.sub(r'<meta name="robots" content="noindex, follow">','<meta name="robots" content="index, follow, max-image-preview:large">',full)
(site/'index.html').write_text(full)
for p in site.glob('*.html'):
 s=p.read_text();s=s.replace('href="/index2#','href="/#').replace('href="/index2"','href="/"');p.write_text(s)
p=site/'_worker.js';s=p.read_text();s=s.replace('"/index2#contact"','"/#contact"')
marker='    // Keep .html aliases'
block='''    if ((request.method === "GET" || request.method === "HEAD") && ["/index2", "/index2/", "/index2.html"].includes(url.pathname)) {
      url.pathname = "/";
      if (url.hostname === CANONICAL_HOST) url.hostname = "www." + CANONICAL_HOST;
      if (url.hostname === "www." + CANONICAL_HOST) url.protocol = "https:";
      return withHeaders(new Response(null, { status: 301, headers: { Location: url.toString() } }), url.pathname);
    }
'''
assert marker in s;p.write_text(s.replace(marker,block+marker))
print('Full homepage restored at /. Deploy wilson-joinery contents; sitemap is already ready.')
