# Wilson Joinery — privacy audit, updated package

Reviewed: 9 October 2026. Scope: local website, worker and policy, with current ICO guidance. Live settings, contracts and business practices were not inspected. This is an implementation audit, not a compliance certification.

## Completed changes and checks

- All Jost font weights used by the site are self-hosted as WOFF. Original SIL Open Font License is included. All nine HTML pages use a local font stylesheet, with no Google Fonts links or preconnections.
- The default form recipient is Wilson's Zoho business inbox: info@wilsonjoinery.co.uk. An existing Cloudflare TO_EMAIL value overrides it: confirm that value and redeploy. Public policy and form notices describe the business setup.
- Policy describes actual required/optional fields, source-page path and timestamp, hosting, Resend, Zoho, Turnstile and technical support by Franks Media.
- Complaints route includes acknowledgement within 30 days and investigation, progress updates and outcome without undue delay.
- Decorative intro sessionStorage flag removed; the animation now runs per page without stored preferences. No application cookie-writing, localStorage or sessionStorage calls remain in the reviewed scripts.
- No analytics, advertising pixels or third-party embeds were found in the package. Inspect live Network/Storage and Cloudflare dashboard additions before concluding no consent mechanism is needed.
- Mandatory server-side Turnstile checks success, hostname and action. Browser explicitly sends the callback token; missing keys block delivery. Body/field limits, escaped email content, same-origin checks and security headers remain.
- Worker/JS checks use mocked providers and do not establish live email delivery, provider configuration, account security or effective deletion.

## Unresolved launch requirements

| Priority | Action |
| --- | --- |
| High | Confirm and publish the full legal data controller identity and suitable contact details. Wilson Joinery currently identifies the trading name; no legal owner or postal address has been supplied. |
| High | Confirm processor relationships and relevant written agreements for Cloudflare, Resend, Zoho and Franks Media's support access. Disclosure is not a substitute for Article 28 arrangements. |
| High | Confirm actual provider countries, account regions and applicable UK international-transfer safeguards. The policy's general transfer description must be made specific to confirmed arrangements; its wording does not prove safeguards exist. |
| High | Approve or revise proposed two-year enquiry and six-year project retention periods, provider retention criteria and a real deletion process covering inbox, sent mail, Trash, logs and backups. The worker does not delete email copies. |
| High | Confirm live TO_EMAIL is info@wilsonjoinery.co.uk, test delivery and Reply-To, and remove unneeded historical test copies. |
| Medium | Implement the promised rights and complaints processes; keep a log, monitor the inbox and respond within applicable deadlines. |
| Medium | Verify MFA, account permissions, restricted API keys, HTTPS and incident handling. Assess whether incidents must be reported within 72 hours. |
| Medium | Record lawful bases and legitimate-interest reasoning, assess ICO fee liability, and consider DPIA/DPO requirements based on the whole business's actual processing. |
| Medium | Inspect cookies and storage on the actual deployment before and after form use; check Cloudflare Web Analytics/Zaraz. Get consent before any technology that requires it. |

## Data flow

Ordinary visits connect to Cloudflare for the site and locally hosted fonts. Using a form loads Cloudflare Turnstile. Security verification sends the token and visitor IP (when supplied by Cloudflare) to Siteverify. Enquiry details, originating path and timestamp pass through the Pages worker and Resend to the configured business mailbox. Franks Media may have support access as described in the policy. There is no separate website enquiry database, but provider logs and mailbox copies may exist.

## Official references

- [ICO privacy information](https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/individual-rights/the-right-to-be-informed/what-privacy-information-should-we-provide/)
- [ICO complaints handling](https://ico.org.uk/for-organisations/how-to-deal-with-data-protection-complaints/)
- [ICO storage/access exceptions](https://ico.org.uk/for-organisations/direct-marketing-and-privacy-and-electronic-communications/guidance-on-the-use-of-storage-and-access-technologies/what-are-the-exceptions/)
- [ICO processor contracts](https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/accountability-and-governance/contracts-and-liabilities-between-controllers-and-processors-multi/what-needs-to-be-included-in-the-contract/)
- [ICO fee self-assessment](https://ico.org.uk/for-organisations/data-protection-fee/data-protection-fee-self-assessment/)
- [Resend DPA](https://resend.com/legal/dpa), [Cloudflare DPA](https://www.cloudflare.com/cloudflare-customer-dpa/), [Turnstile privacy](https://www.cloudflare.com/turnstile-privacy-policy/), [Zoho privacy](https://www.zoho.com/privacy.html)

## SEO/coming-soon package changes
The subsequent SEO package adds sitemap/robots, consistent metadata and clean URLs, and extracts compressed local images. Full homepage is now /index2, with noindex; coming-soon is /. Forms use 16px text. These changes do not resolve the outstanding legal identity, contracts, retention or live verification requirements above.
